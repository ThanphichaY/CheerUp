import SwiftUI

struct MainView: View {//open mainview
    var body: some View{//open body
        NavigationView{//open navigation
            VStack{//open Vstack
                Image(uiImage: UIImage(named:"logo.png")!)
                    .renderingMode(.original)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .padding()
                    .offset(y:-70)
                    
                HStack{//open hstack
                    VStack{//open vstack2
                        NavigationLink(destination: CheerUpView()) {//open navigation link
                            Image(uiImage: UIImage(named:"cheer.png")!)
                                .renderingMode(.original)
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .clipShape(Circle())
                                .padding(.leading, 20)
                                .offset(y:-20)
                        }//close navigation l nk
                        Text("Cheer Up Now")
                            .font(.system(size: 20, weight: .semibold))
                            .foregroundColor(.pink)
                            .offset(y:-20)
                            .padding(.bottom, 40)
                            .padding(.leading, 20)
                    }//close vstack 2
                    VStack{//open vstack 3
                        NavigationLink(destination: DeveloperView()){//open navigationlink 2
                            Image(uiImage: UIImage(named:"dev.png")!)
                                .renderingMode(.original)
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .clipShape(Circle())
                                .padding(.trailing, 20)
                                .offset(y: -20)
                        }//close navigationlink 2
                        Text("Developer")
                            .font(.system(size: 20, weight:.semibold))
                            .foregroundColor(.pink)
                            .offset(y:-20)
                            .padding(.bottom, 40)
                            .padding(.trailing, 20)
                    }//close vstack 3
                }//close hstack
            }//close vstack
        }//close navigation
    }//close body
    
}//close mainview
