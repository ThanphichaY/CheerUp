import SwiftUI

struct DeveloperView: View {//open cheer uo view
    var body: some View{//open body
        VStack{//open vstack
            Text("About Developer")
                .font(.system(size: 24, weight: .bold))
                .foregroundColor(.primary)
                .offset(y:-20)
            
            Image(uiImage: UIImage(named: "tan.JPG")!)
                .renderingMode(.original)
                .resizable()
                .padding(50)
                .aspectRatio(contentMode: .fit)
                .offset(y:-20)
            
            
            Text("Thanphicha Yimlamai (Tan)")
                .font(.system(size: 22, weight: .semibold))
                .foregroundColor(.primary)
                .offset(y:-50)
            Text("Student at Chulalonglorn University")
                .font(.system(size: 18, weight: .semibold))
                .foregroundColor(.primary)
                .offset(y:-50)
            Text("thanphicha.y@gmail.com")
                .font(.system(size: 18, weight: .semibold))
                .foregroundColor(.primary)
                .offset(y:-50)
                    
        }//close vstack
        
    }//close body
}//close cheer up view

