import SwiftUI
import AVFoundation

struct CheerUpView: View {//open cheer up view
    
    @State private var Result : String = ""
    @State var imgid : Int = 0
    @State var imgid2 : Int = 0
    @State var description1: String = ""
    @State var description2: String = ""
    @State private var tapCount = 0
    
    
    func voiceCheerUp(imgid : Int, imgid2 : Int) -> String{//open func
        var voiceResult : String = ""
        if imgid == 1 && imgid2 == 10 {
            voiceResult += "I understand you dear. I know how it feels. Don't keep it. Let yourself feel everything you need to feel. You will feel happier as the time passes, I promise. You deserve so much better and I believe you will find the right one. Keep fighting and be happy."
        }
        else if imgid == 1 && imgid2 == 11 {
            voiceResult += "I don't know the exact problem between you and your friend. But I believe it will get better soon. You can talk to your friend with reasons and make it up. So, please don't be sad and keep smiling."
        }
        else if imgid == 1 && imgid2 == 13 {
            voiceResult += "I understand how you feel but it must have a way out for this problem. Everything will be alright. Please don't be sad. Keep fighting. I'm always here when you need me"
        }
        else if imgid == 1 && imgid2 == 14 {
            voiceResult += "I'm truly sorry for your loss. It rests in peace now. I think your lovely pet is a little angel somewhere in the sky. It will absolutely miss you. Don't be sad. Move forward and keep it in your heart"
        }
        else if imgid == 1 && imgid2 == 15 {
            voiceResult += "I'm truly sorry for your loss. I understand how painful it is but the time will heal. I believe you will get through this hard time and your loved one will be in your heart. So, please be cheerful and live your life happily"
        }
        else if imgid == 1 && imgid2 == 16 {
            voiceResult += "I understand how bad it is to be bullied. But don't let that nonsense speech take over you. Those words are not worth caring for. You are not what they say. Leave it and be happy. I always support you. Keep fighting"
        }
        else if imgid == 1 && imgid2 == 17 {
            voiceResult += "Whoever ignores you. Leave them. You have many people who care about you. Your mom, your dad, other friends. So, be happy and do whatever you love to."
        }
        else if imgid == 2 && imgid2 == 11 {
            voiceResult += "I understand to feel angry for something. But having an argument does't actually help. Why don't you calm down and figure it out with reasons. Everything will get better and you and your friend will understand each other well. So, be cheerful and positive. Fighting"
        }
        else if imgid == 2 && imgid2 == 16 {
            voiceResult += "I understand you to feel angry. But that's what they want to be. Ignore them and their words. You're not what they say. Be happy and live your life whatever you want."
        }
        else if imgid == 2 && imgid2 == 17 {
            voiceResult += "You don't have to be angry for people who don't care about you. I believe you are loved abn cared by many people around you. You should let it go and stay calm. You will be happier with your life, trust me. Be cheerful."
        }
        else if imgid == 3 && imgid2 == 13 {
            voiceResult += "Don't pressure yourself too much. There will be a way out of this problem. Maybe you need to consult with your family. You will get through it believe me. I want you to be cheerful. Go and get your life enjoyable. Fighting"
        }
        else if imgid == 3 && imgid2 == 11 {
            voiceResult += "You shouldn't waste your energy for argument. Things will never get better. You need to calm down and talk to your friend. That will make you less tired and better understanding with each other. And don't forget to relax yourself. Keep fighting."
        }
        else if imgid == 3 && imgid2 == 12 {
            voiceResult += "If you're tired of work, then take a rest. Give yourself a break and find something to do to relax. Maybe taking a nap. and when you feel more energetic, then continue your work. I believe you can do it. Keep fighting."
        }
        else if imgid == 3 && imgid2 == 16 {
            voiceResult += "You don't have to care what they say about you. Don't even listen to. If you're tired of those words, just forget it and relax. Be the way you want to be. The way that you're happy for. I will always cheer you up. Keep fighting."
        }
        else if imgid == 4 && imgid2 == 11 {
            voiceResult += "If having an argument leads you to stress, you'd better stop it. Maybe talking politely with reasons will leasd you and your friend to solution and better atmosphere. So, please be cheerful and happy."
        }
        else if imgid == 4 && imgid2 == 12 {
            voiceResult += "Don't pressure yourself too much. Just do it little by little alternating with have some relax everyday. I believe your work will finish and you're not too stress. By the way, keep fighting. You can absolutely do it."
        }
        else if imgid == 4 && imgid2 == 13 {
            voiceResult += "It seems to be a big problem to make you stressed. Don't keep it to yourself. You'd better talk with someone or ask for help. If it gets worse, stop thinking about it for a while. I believe there will be a way to solve. Keep fighting and relax yourself."
        }
        else if imgid == 4 && imgid2 == 14 {
            voiceResult += "I'm sorry for your loss. Don't be too stressed. Imagine your lovely pet is a little angel now. It rests in peace. All you have to do is let things go and live your life happily."
        }
        else if imgid == 4 && imgid2 == 15 {
            voiceResult += "I'm sorry for your loss. I understand how you feel. But your loved one rests in peace now. You have to move forward. Don't stuck with your stress and get worse mental health. You will get through it one day. Keep fighting."
        }
        else if imgid == 4 && imgid2 == 16 {
            voiceResult += "Please don't be too stressed from those nonsense and untrue words. I don't want you to get worse. Leave it. You don't have to care for that. Believe in yourself and be the best version of you. Be happy. Keep fighting."
        }
        else if imgid == 5 && imgid2 == 10 {
            voiceResult += "You're lonely for a while but I believe you will get through this bad time. One day you will find the right one for you. So, let's move forward and live your life cheerfully with your friends and family."
        }
        else if imgid == 5 && imgid2 == 15 {
            voiceResult += "I'm sorry for your loss. I understand how lonely you are. I hope you will get through this hard time and be happy again. Your family and your friends are with you including me. I'm always here for you. Keep fighting."
        }
        else if imgid == 5 && imgid2 == 17 {
            voiceResult += "It's alright. You're not alone. You still have your family, your other friends and those who support you including me. I'm here for you. Be happy and keep fighting."
        }
        else {
            voiceResult += "Whatever the actual problem is, you will be alright and get over the bad moment. What makes you feel bad and hurt your feeling just forget it. Live your life happily every single day. You always have me. Keep fighting."
        }
        return voiceResult
    }//close func
    
   
    
    var body: some View{//open body
        
        
        
        ScrollView(.vertical, showsIndicators: false) {//close scrollview1
            
                    
            VStack{//open vstack
                VStack(alignment: .leading) {//open vstack2
            Text("How are you feeling?")
                .fontWeight(.bold)
                
                .font(.system(size: 20))
                .foregroundColor(.pink)
                .offset (y: -20)
          
                
                    ScrollView(.horizontal, showsIndicators: false) {//open scroll2
                        
                        ZStack{//open zstack
                            Color.init(red: 0.9882, green: 0.8902, blue: 0.949)
                                .offset(y: -50)
                            HStack{//open hstack
                                
                            VStack{//open vstack2
                                Text("Sad")
                                    .foregroundColor(.secondary)
                                    .font(.system(size: 16, weight: .semibold))
                                    .offset(y: -10)
                                    .padding(20)
                                    
                                Button(action :{
                                        self.imgid = 1
                                    self.description1 = "You're sad"
                                    
                                }){
                                    Image(uiImage: UIImage(named:"sad.jpeg")!)
                                       .resizable()
                                       .aspectRatio(contentMode: .fill)
                                       .frame(width: 130, height: 160)
                                       .clipShape(Circle())
                                       .hoverEffect(.highlight)
                                        .offset(y: -50)
                                        .padding(20)
                                    
                                }
                            }//close vstack2
                            
                            VStack{//open vstack3
                                Text("Angry")
                                    .foregroundColor(.secondary)
                                    .font(.system(size: 16, weight: .semibold))
                                    .offset(y: -10)
                                    .padding(20)
                                
                                  Button(action :{self.imgid = 2
                                    self.description1 = "You're angry"
                                }){
                                    Image(uiImage: UIImage(named:"angry.jpeg")!)
                                       .resizable()
                                       .aspectRatio(contentMode: .fill)
                                       .frame(width: 130, height: 160)
                                       .clipShape(Circle())
                                       .hoverEffect(.highlight)
                                        .offset(y: -50)
                                        .padding(20)
                                    
                                    
                                }
                            }//close vstack3
                            
                            VStack{//open vstack4
                                Text("Tired")
                                    .foregroundColor(.secondary)
                                    .font(.system(size: 16, weight: .semibold))
                                    .offset(y: -10)
                                    .padding(20)
                                
                                Button(action :{self.imgid = 3
                                    self.description1 = "You're tired"
                                }){
                                    Image(uiImage: UIImage(named:"tired.jpeg")!)
                                       .resizable()
                                       .aspectRatio(contentMode: .fill)
                                       .frame(width: 130, height: 160)
                                       .clipShape(Circle())
                                       .hoverEffect(.highlight)
                                        .offset(y: -50)
                                        .padding(20)
                                    
                                    
                                }
                            }//close vstack4
                            
                            VStack{//open vstack5
                                Text("Stressed")
                                    .foregroundColor(.secondary)
                                    .font(.system(size: 16, weight: .semibold))
                                    .offset(y: -10)
                                    .padding(20)
                                
                                Button(action :{self.imgid = 4
                                    self.description1 = "You're stressed"
                                }){
                                    Image(uiImage: UIImage(named:"stress.jpeg")!)
                                       .resizable()
                                       .aspectRatio(contentMode: .fill)
                                       .frame(width: 130, height: 160)
                                       .clipShape(Circle())
                                       .hoverEffect(.highlight)
                                        .offset(y: -50)
                                        .padding(20)
                                    
                                    
                                }
                            }//close vstack5
                            
                            VStack{//open vstack6
                                Text("Lonely")
                                    .foregroundColor(.secondary)
                                    .font(.system(size: 16, weight: .semibold))
                                    .offset(y: -10)
                                    .padding(20)
                                
                                
                                Button(action :{self.imgid = 5
                                    self.description1 = "You're lonely"
                                }){
                                    Image(uiImage: UIImage(named:"lonely.jpeg")!)
                                       .resizable()
                                       .aspectRatio(contentMode: .fill)
                                       .frame(width: 130, height: 160)
                                       .clipShape(Circle())
                                       .hoverEffect(.highlight)
                                        .offset(y: -50)
                                        .padding(20)
                                    
                                    
                                }
                            }//close vstack6
                            Spacer()
                            }//close hstack
                        }//close zstack
                    }//close Scrollview2
                }//close vstack2
                
                VStack(alignment: .leading){//vstack 3
                Text("What makes you feel like that?")
                    .fontWeight(.bold)
                    .font(.system(size: 20))
                    .foregroundColor(.purple)
                    .offset (y: -20)
                        
                ScrollView(.horizontal, showsIndicators: false) {//open scroll2
                    
                    ZStack{//open zstack2
                        Color.init(red: 0.8902, green: 0.902, blue: 0.9882)
                            .offset(y : -50)
                    
                        HStack{//open hstack2}
                        VStack{//open vstack7
                            Text("Breaking up")
                                .foregroundColor(.secondary)
                                .font(.system(size: 16, weight: .semibold))
                                .offset(y: -10)
                                .padding(20)
                            
                            
                            
                            Button(action :{self.imgid2 = 10
                                self.description2 = "you broke up with your boyfriend/girlfriend."
                            }){
                                Image(uiImage: UIImage(named:"breakup.jpeg")!)
                                   .resizable()
                                   .aspectRatio(contentMode: .fill)
                                   .frame(width: 130, height: 160)
                                   .clipShape(Circle())
                                   .hoverEffect(.highlight)
                                    .offset(y: -50)
                                    .padding(20)
                                
                            }
                        }//close vstack7
                        
                        VStack{//open vstack8
                            Text("Having an argument")
                                .foregroundColor(.secondary)
                                .font(.system(size: 16, weight: .semibold))
                                .offset(y: -10)
                                .padding(20)
                            
                            
                            Button(action :{self.imgid2 = 11
                                self.description2 = "you have an argument with someone."
                            }){
                                Image(uiImage: UIImage(named:"argue.jpeg")!)
                                   .resizable()
                                   .aspectRatio(contentMode: .fill)
                                   .frame(width: 130, height: 160)
                                   .clipShape(Circle())
                                   .hoverEffect(.highlight)
                                    .offset(y: -50)
                                    .padding(20)
                                
                            }
                        }//close vstack8
                        
                        VStack{//open vstack9
                            Text("Loads of work")
                                .foregroundColor(.secondary)
                                .font(.system(size: 16, weight: .semibold))
                                .offset(y: -10)
                                .padding(20)
                            
                            
                            Button(action :{self.imgid2 = 12
                                self.description2 = "you have a lot of work to finish."
                            }){
                                Image(uiImage: UIImage(named:"work.jpeg")!)
                                   .resizable()
                                   .aspectRatio(contentMode: .fill)
                                   .frame(width: 130, height: 160)
                                   .clipShape(Circle())
                                   .hoverEffect(.highlight)
                                    .offset(y: -50)
                                    .padding(20)
                                
                            }
                        }//close vstack9
                        
                        VStack{//open vstack10
                            Text("Financial problem")
                                .foregroundColor(.secondary)
                                .font(.system(size: 16, weight: .semibold))
                                .offset(y: -10)
                                .padding(20)
                            
                            
                            Button(action :{self.imgid2 = 13
                                self.description2 = "you have a financial problem."
                            }){
                                Image(uiImage: UIImage(named:"money.jpeg")!)
                                   .resizable()
                                   .aspectRatio(contentMode: .fill)
                                   .frame(width: 130, height: 160)
                                   .clipShape(Circle())
                                   .hoverEffect(.highlight)
                                    .offset(y: -50)
                                    .padding(20)
                                
                            }
                        }//close vstack10
                        
                        VStack{//open vstack11
                            Text("Your pet died")
                                .foregroundColor(.secondary)
                                .font(.system(size: 16, weight: .semibold))
                                .offset(y: -10)
                                .padding(20)
                            
                            
                            Button(action :{self.imgid2 = 14
                                self.description2 = "your pet was gone."
                            }){
                                Image(uiImage: UIImage(named:"deadpet.jpeg")!)
                                   .resizable()
                                   .aspectRatio(contentMode: .fill)
                                   .frame(width: 130, height: 160)
                                   .clipShape(Circle())
                                   .hoverEffect(.highlight)
                                    .offset(y: -50)
                                    .padding(20)
                                
                            }
                        }//close vstack11
                        
                        VStack{//open vstack12
                            Text("Someone you love died")
                                .foregroundColor(.secondary)
                                .font(.system(size: 16, weight: .semibold))
                                .offset(y: -10)
                                .padding(20)
                            
                            
                            Button(action :{self.imgid2 = 15
                                self.description2 = "someone you love was gone."
                            }){
                                Image(uiImage: UIImage(named:"deadpeople.jpeg")!)
                                   .resizable()
                                   .aspectRatio(contentMode: .fill)
                                   .frame(width: 130, height: 160)
                                   .clipShape(Circle())
                                   .hoverEffect(.highlight)
                                    .offset(y: -50)
                                    .padding(20)
                                
                            }
                        }//close vstack12
                        
                        VStack{//open vstack13
                            Text("Being bullied")
                                .foregroundColor(.secondary)
                                .font(.system(size: 16, weight: .semibold))
                                .offset(y: -10)
                                .padding(20)
                            
                            
                            Button(action :{self.imgid2 = 16
                                self.description2 = "someone has bullied you."
                            }){
                                Image(uiImage: UIImage(named:"bully.jpeg")!)
                                   .resizable()
                                   .aspectRatio(contentMode: .fill)
                                   .frame(width: 130, height: 160)
                                   .clipShape(Circle())
                                   .hoverEffect(.highlight)
                                    .offset(y: -50)
                                    .padding(20)
                                
                            }
                        }//close vstack13
                        
                        VStack{//open vstack3
                            Text("Being ignored")
                                .foregroundColor(.secondary)
                                .font(.system(size: 16, weight: .semibold))
                                .offset(y: -10)
                                .padding(20)
                            
                            
                            Button(action :{self.imgid2 = 17
                                self.description2 = "you were ignored by surrounded people."
                            }){
                                Image(uiImage: UIImage(named:"ignore.jpeg")!)
                                   .resizable()
                                   .aspectRatio(contentMode: .fill)
                                   .frame(width: 130, height: 160)
                                   .clipShape(Circle())
                                   .hoverEffect(.highlight)
                                    .offset(y: -50)
                                    .padding(20)
                                
                            }
                        }//close vstack3
                        }//closehstack2
                    }//close zstack2
                    }//close scrollview2
                }//close vstack 3
                
                Text("An Encouragement For You")
                    .font(.system(size: 20))
                    .foregroundColor(.gray)
                    .fontWeight(.bold)
                    .padding(10)
                    .offset(y: -40)
                if(!description1.isEmpty && !description2.isEmpty){
                    Text("\(description1) because \(description2)")
                        .font(.system(size: 16))
                        .foregroundColor(.secondary)
                        .offset(y: -50)
                }
                HStack{//open hstack
                Button(action : {
                    self.Result = self.voiceCheerUp(imgid: Int(self.imgid), imgid2: Int(self.imgid2))
                    let mySpeech = AVSpeechUtterance(string: self.Result)
                    mySpeech.voice = AVSpeechSynthesisVoice(language: "en-US")
                    let mySpeeckSynthesizer = AVSpeechSynthesizer()
                    mySpeeckSynthesizer.speak(mySpeech)
                }){
                    Image(systemName: "speaker.wave.3.fill")
                        .background(Color.green)
                        .foregroundColor(Color.white)
                        .font(.system(size: 50))
                        .cornerRadius(10)
                        .padding(10)
                }
                    VStack{
                    Button("Yes : \(tapCount)"){
                        tapCount+=1
                    }
                    .foregroundColor(.gray)
                    .frame(width: 70, height: 40, alignment: .center)
                    .background(Color.init(red: 0.898, green: 0.8902, blue: 0.8941))
                    Text("You feel better now?")
                        .font(.system(size: 14, weight: .light))
                        .foregroundColor(Color.secondary)
                    }//close vstav=ck
                    .padding(.trailing, -10)
                    
                }//close hstack
                .padding(.horizontal, 30)
                Spacer()
                
                }//close vstack
            
            }//close scroll
        
    }//close body
}//close cheer up view

